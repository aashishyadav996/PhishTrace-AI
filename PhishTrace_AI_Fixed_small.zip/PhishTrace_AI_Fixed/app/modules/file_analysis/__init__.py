"""
Generic file analysis module.
"""
